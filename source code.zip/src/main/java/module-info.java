module com.dante.connectfour.connect4 {
	requires javafx.controls;
	requires javafx.fxml;


	opens com.dante.connect4 to javafx.fxml;
	exports com.dante.connect4;
}