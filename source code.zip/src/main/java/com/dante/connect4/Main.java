package com.dante.connect4;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;

public class Main extends Application {

	public Controller controller;
	@Override
	public void start(Stage primaryStage) throws IOException {

		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("gamefile.fxml"));
		GridPane rootnodeGridPane = fxmlLoader.load();
		controller = fxmlLoader.getController();
		Scene scene = new Scene(rootnodeGridPane);
		controller.createPlayground();

		MenuBar menuBar = createMenu();
		menuBar.prefWidthProperty().bind(primaryStage.widthProperty());

		Pane menuPane = (Pane) rootnodeGridPane.getChildren().get(0);
		menuPane.getChildren().add(menuBar);

		primaryStage.setTitle("Connect Four");
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.setResizable(false);



	}

	private MenuBar createMenu() {


		Menu fileMenu = new Menu("File");
		MenuItem newMenuItem = new MenuItem("New Game");
		newMenuItem.setOnAction(event -> controller.resetGame());

		MenuItem restartMenuItem = new MenuItem("Restart Game");
		newMenuItem.setOnAction(event -> controller.resetGame());

		MenuItem exitMenuItem = new MenuItem("Exit Game");
		exitMenuItem.setOnAction(event -> exitGame() );

		SeparatorMenuItem separatorMenuItem = new SeparatorMenuItem();
		fileMenu.getItems().addAll(newMenuItem,restartMenuItem,separatorMenuItem,exitMenuItem);


		Menu aboutMenu = new Menu("About");
		MenuItem creatorMenuItem = new MenuItem("Game Info");
		creatorMenuItem.setOnAction(event -> aboutConnect4());

		MenuItem aboutMenuItem = new MenuItem("Creator");
		aboutMenuItem.setOnAction(event -> aboutMe());
		SeparatorMenuItem separatorMenuItem1 = new SeparatorMenuItem();
		aboutMenu.getItems().addAll(creatorMenuItem,separatorMenuItem1,aboutMenuItem);

		MenuBar menuBar = new MenuBar();
		menuBar.getMenus().addAll(fileMenu,aboutMenu);


		return menuBar;
	}

	private void aboutMe() {
		Alert alert = new Alert(Alert.AlertType.INFORMATION);
		alert.setTitle("About Creator");
		alert.setHeaderText("Debasish Mohapatra");
		alert.setContentText("I just like to " +
				"create and test games of all types." +
				"This is my 1st Game in Java from scratch");
		alert.show();
	}

	private void aboutConnect4() {
		Alert alert = new Alert(Alert.AlertType.INFORMATION);
		alert.setTitle("About Connect Four");
		alert.setHeaderText("How to Play");
		alert.setContentText("Connect Four is a two-player connection game in which " +
				"the players first choose a color and then take turns dropping" +
				" colored discs from the top into a seven-column, " +
				"six-row vertically suspended grid. " +
				"The pieces fall straight down, occupying the next" +
				" available space within the column. " +
				"The objective of the game is to be the" +
				" first to form a horizontal, vertical, " +
				"or diagonal line of four of one's own discs." +
				" Connect Four is a solved game." +
				" The first player can always win " +
				"by playing the right moves.");
		alert.show();
	}

	private void exitGame() {
		Platform.exit();
		System.exit(0);
	}



	public static void main(String[] args) {
		launch();
	}
}